const cities = [
  { name: "Bangalore", state: "Karnataka" },
  { name: "Bhopal", state: "Madhya Pradesh" },
  { name: "Chandigarh", state: "Chandigarh" },
  { name: "Chennai", state: "Tamil Nadu" },
  { name: "Delhi", state: "Delhi" },
  { name: "Hyderabad", state: "Telangana" },
  { name: "Jaipur", state: "Rajasthan" },
  { name: "Kolkata", state: "West Bengal" },
  { name: "Lucknow", state: "Uttar Pradesh" },
  { name: "Mumbai", state: "Maharashtra" },
  { name: "Patna", state: "Bihar" },
  { name: "Pune", state: "Maharashtra" },
  { name: "Udaipur", state: "Rajasthan" },
];

export default cities;
